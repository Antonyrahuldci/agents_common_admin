export const appConstants = {
  // baseUrl: "http://localhost:4000/api/v1/admin",
  baseUrl: "https://backend-demo.simbli.ai/api/v1/admin",
  appName: "VISL",
};
