export const apiConstants = {
    handleSearchOnChange: "HANDLE_SEARCH_ON_CHANGE", 
    apiLoginInitiate: "API_LOGIN_INITIATE",
    apiLoginSuccess: "API_LOGIN_SUCCESS"
  };
  