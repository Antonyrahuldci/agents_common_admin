export const pageRoutes = {
  login: "/",
  dashboard: "/dashboard",
  mail: "/send-mail",
  wailistusers: "/waitlist-users",
};
